source install/setup.bash
ros2 launch sample build_map.launch.py
