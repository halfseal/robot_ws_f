source install/setup.bash
ros2 launch sample cartographer.launch.py
